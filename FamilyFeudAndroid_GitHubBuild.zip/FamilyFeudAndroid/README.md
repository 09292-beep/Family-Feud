# Family Feud Android app project

This is an Android Studio project wrapper for the Family Feud quiz game.

## Build an APK
1. Install Android Studio on a computer.
2. Open this folder (`FamilyFeudAndroid`) in Android Studio.
3. Allow Gradle sync to finish and install any requested Android SDK.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK is typically created at:
   `app/build/outputs/apk/debug/app-debug.apk`
6. Transfer the APK to your Android phone and install it. If prompted, allow installing apps from that source.

## Online leaderboard note
The game currently includes Firebase placeholders. For a truly shared online leaderboard:
1. Create a Firebase project and a Firestore database.
2. Replace the `firebaseConfig` placeholders in `app/src/main/assets/index.html` with your Firebase web app config.
3. Configure Firestore rules and indexes as appropriate.
4. Rebuild the APK.

Without Firebase configuration, the game can still play and keep local scores, but players on different phones will not share leaderboard scores.

This project is a starter app project, not a compiled APK. Building the APK requires Android Studio/Android SDK.


## Build APK from GitHub using your phone

The repository contains `.github/workflows/build-apk.yml`. GitHub Actions can build the APK in the cloud; you do not need Android Studio on your phone.

For the workflow to find the ZIP, upload the project archive to the repository root and name it exactly `FamilyFeudAndroid_Project.zip`. The workflow extracts it and runs Gradle, then uploads the APK as a workflow artifact.

See the user instructions in ChatGPT for the phone-based GitHub steps.
